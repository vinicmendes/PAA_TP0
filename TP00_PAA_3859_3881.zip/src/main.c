#include "menu.h"

int main()
{
    gera_menu();
    return 0;
}