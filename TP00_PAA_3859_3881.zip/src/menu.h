#include "quadro.h"

int gera_menu();